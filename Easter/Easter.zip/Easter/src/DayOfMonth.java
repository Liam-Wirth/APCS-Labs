public class DayOfMonth {
	public int day;
	public int month;

	public DayOfMonth(int day2, int month2) {
		day = day2;
		month = month2;

	}
}
